import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    // Inline small assets — keeps the dist folder to a single HTML + JS file
    assetsInlineLimit: 100_000,
  },
})
