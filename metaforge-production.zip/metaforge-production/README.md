# MetaForge — Production Launch Guide

> AI-powered React Native app builder for Google Play  
> Built with Vite + React + TypeScript · Deploy to Netlify in 5 minutes

---

## Before You Deploy

Complete these two things first. Neither costs money to start.

### 1. Update your Lemon Squeezy store URL

Open `src/App.tsx` and find line ~892:

```ts
const STORE_URL = "https://metaforge.lemonsqueezy.com";
```

Replace the URL with your actual Lemon Squeezy store link once your store is approved.

### 2. Note your license key format

MetaForge accepts any alphanumeric Lemon Squeezy license key (8–64 characters).
Lemon Squeezy keys are delivered automatically to customers by email after purchase — no extra setup needed on your end.

---

## Option A — Netlify Drop (fastest, no account required)

This is the drag-and-drop method. Zero command line.

**Step 1** — Build the project on your computer

Open a terminal in this folder and run:

```bash
npm install
npm run build
```

This creates a `dist/` folder containing the complete production app.

**Step 2** — Go to Netlify Drop

Open your browser and go to: **https://app.netlify.com/drop**

**Step 3** — Drag the `dist` folder

Drag and drop the `dist/` folder directly onto the Netlify Drop page.

**Step 4** — Done

Netlify gives you a free URL like `https://amazing-name-123.netlify.app` within 30 seconds.
Your app is live. Share that URL with your first customers.

> **To use a custom domain** (e.g. metaforge.app), create a free Netlify account, claim the site, and add your domain in Site Settings → Domain Management.

---

## Option B — Netlify CLI (one command, auto-deploys on push)

```bash
npm install -g netlify-cli
netlify login
netlify deploy --prod --dir=dist
```

---

## Option C — GitHub + Netlify (recommended for ongoing updates)

1. Push this folder to a GitHub repository
2. Go to https://app.netlify.com → New site → Import from GitHub
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Click Deploy — every `git push` auto-deploys from now on

---

## Local Development

```bash
npm install       # install dependencies (one time)
npm run dev       # start local dev server at http://localhost:5173
npm run build     # build production bundle to dist/
npm run preview   # preview the production build locally
```

---

## File Structure

```
metaforge/
├── index.html          ← HTML entry point (Vite)
├── netlify.toml        ← Netlify deploy + security headers
├── package.json        ← dependencies and scripts
├── tsconfig.json       ← TypeScript config
├── tsconfig.node.json  ← TypeScript config for Vite
├── vite.config.ts      ← Vite build configuration
├── README.md           ← this file
└── src/
    ├── main.tsx        ← React entry point
    └── App.tsx         ← entire MetaForge application (~1,600 lines)
```

---

## Updating Your Store URL

When your Lemon Squeezy store goes live:

1. Open `src/App.tsx`
2. Find `const STORE_URL`
3. Paste your actual store URL
4. Run `npm run build` again
5. Re-deploy the new `dist/` folder to Netlify

That's the only change needed. Everything else is already production-ready.

---

## What Your Customers Get

After purchasing and receiving their license key from Lemon Squeezy:

1. They visit your MetaForge URL
2. They click **⚙ Settings** in the top bar
3. They paste their license key + their Anthropic API key
4. They click **Save & Activate** — the app unlocks immediately
5. They describe any app and click **Generate App**

Keys are stored in their browser's localStorage — no server, no database required.

---

## How the License Check Works

`src/App.tsx` — `isLicenseValid()` function:

```ts
function isLicenseValid(key: string): boolean {
  if (!key || !key.trim()) return false;
  // Accepts any Lemon Squeezy license key (alphanumeric, 8–64 chars)
  return /^[a-zA-Z0-9_-]{8,64}$/.test(key.trim());
}
```

This client-side check gates the UI. For production at scale, you can add a server-side verification step by calling the [Lemon Squeezy License API](https://docs.lemonsqueezy.com/api/license-keys) from a Netlify Function — but client-side is sufficient to launch.

---

## Pricing & Revenue

| Item | Detail |
|---|---|
| Your product price | $35 one-time |
| Lemon Squeezy fee | 5% + $0.50 per transaction |
| Your take per sale | ~$32.75 |
| Break-even (server cost) | $0 — fully serverless |
| Hosting cost | $0 — Netlify free tier |

---

*Built with MetaForge · Powered by Claude AI*
