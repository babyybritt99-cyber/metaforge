import { useState, useCallback, useRef, useEffect } from "react";

/* ══════════════════════════════════════════════════════════════
   FONTS + GLOBAL STYLES
══════════════════════════════════════════════════════════════ */
const FONTS = `@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=JetBrains+Mono:wght@400;500;600&family=Instrument+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap');`;
const BASE = `
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:#0c0c0f;color:#f1f0ee;font-family:'Instrument Sans',sans-serif}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:#0c0c0f}
::-webkit-scrollbar-thumb{background:#2a2a38;border-radius:3px}
button,input,textarea,select{font-family:inherit;outline:none}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes pdot{0%,100%{opacity:1}50%{opacity:.25}}
@keyframes fi{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
@keyframes mi{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:none}}
@keyframes pulse-ring{0%{transform:scale(1);opacity:.8}100%{transform:scale(1.6);opacity:0}}
@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}
`;

/* ── Palette ── */
const T = {
  bg:"#0c0c0f", bg1:"#0e0e16", bg2:"#14141e", bg3:"#1a1a26", bg4:"#202030",
  border:"#1e1e2a", border2:"#2a2a38", border3:"#363650",
  amber:"#f59e0b", amber2:"#d97706", amberDim:"#f59e0b22",
  green:"#34d399", greenDim:"#34d39920",
  red:"#f87171",   redDim:"#f8717120",
  blue:"#60a5fa",  blueDim:"#60a5fa20",
  violet:"#a78bfa",
  text:"#f1f0ee", text2:"#9998a8", text3:"#5a5a6e", text4:"#3a3a58",
};

/* ── Style helpers ── */
const mono = (x={}) => ({ fontFamily:"'JetBrains Mono',monospace",...x });
const sans = (x={}) => ({ fontFamily:"'Instrument Sans',sans-serif",...x });
const syne = (x={}) => ({ fontFamily:"'Syne',sans-serif",...x });
const lbl  = (x={}) => mono({ fontSize:10, color:T.text3, textTransform:"uppercase", letterSpacing:"0.09em",...x });
const pill = (color, x={}) => mono({ fontSize:9, padding:"2px 8px", borderRadius:20,
  background:`${color}20`, color, border:`1px solid ${color}44`,...x });

/* ══════════════════════════════════════════════════════════════
   LOGIC ENGINE  (wires to Claude API)
══════════════════════════════════════════════════════════════ */

/* Complexity keyword detector */
function detectComplexity(prompt) {
  const p = prompt.toLowerCase();
  const complexKw = ["payment","stripe","api","real-time","websocket","map","camera","oauth","firebase","chart","analytics"];
  const mediumKw  = ["login","auth","profile","search","favourites","favorites","saved","notification","dashboard","form"];
  if (complexKw.some(k => p.includes(k))) return "complex";
  if (mediumKw.some(k => p.includes(k)))  return "medium";
  return "simple";
}

/* Permission inferencer */
function inferPerms(prompt) {
  const p = prompt.toLowerCase();
  const perms = [];
  if (p.includes("camera")||p.includes("photo")||p.includes("scan"))  perms.push("CAMERA");
  if (p.includes("map")||p.includes("location")||p.includes("gps"))   perms.push("ACCESS_FINE_LOCATION");
  if (p.includes("microphone")||p.includes("voice")||p.includes("audio")) perms.push("RECORD_AUDIO");
  if (p.includes("gallery")||p.includes("file")||p.includes("attachment")) perms.push("READ_EXTERNAL_STORAGE");
  if (p.includes("vibrat")||p.includes("haptic")) perms.push("VIBRATE");
  if (p.includes("fingerprint")||p.includes("biometric")) perms.push("USE_BIOMETRIC");
  const needsNet = ["api","fetch","weather","firebase","login","auth","real-time","payment","stripe","map","upload","download","chart"];
  if (needsNet.some(k => p.includes(k))) perms.push("INTERNET");
  return [...new Set(perms)];
}

/* Build system prompt */
function buildSystemPrompt(complexity, perms) {
  const permList = perms.length ? perms.join(", ") : "none";
  const allowedComponents = complexity === "simple"
    ? "TextBlock, ButtonBlock, InputBlock, ListBlock, CardBlock, ImageBlock, FormBlock, NavigationBarBlock, ModalBlock"
    : complexity === "medium"
    ? "TextBlock, ButtonBlock, InputBlock, ListBlock, CardBlock, ImageBlock, FormBlock, NavigationBarBlock, TabBarBlock, ModalBlock, AuthGateBlock, ApiDataBlock, ChartBlock"
    : "ALL 15 component types including MapBlock, PaymentBlock, ApiDataBlock, ChartBlock, AuthGateBlock";

  return `You are a React Native app code generator. You must respond with ONLY a valid JSON object — no markdown, no backticks, no prose. Output must be valid JSON only.

COMPLEXITY TIER: ${complexity.toUpperCase()}
REQUIRED ANDROID PERMISSIONS: ${permList}
MINIMUM PERMISSIONS PRINCIPLE: Only include permissions actually required by the described features.

OUTPUT: A single JSON object with this exact shape:
{
  "id": "uuid-v4 string",
  "name": "short app name (no spaces)",
  "description": "restate the user prompt",
  "createdAt": "ISO 8601 timestamp",
  "updatedAt": "ISO 8601 timestamp",
  "version": 1,
  "complexity": "${complexity}",
  "screens": [array of Screen objects],
  "globalState": {"keys": {stateKey: {"type":"string|number|boolean|array|object","defaultValue":value,"persistLocally":bool}}},
  "theme": {"primaryColor":"#hex","secondaryColor":"#hex","backgroundColor":"#hex","textColor":"#hex","fontFamily":"System","borderRadius":"md","darkMode":true},
  "navigation": {"type":"stack|tab|drawer","tabs":[{"label":"str","icon":"str","screenId":"str"}]},
  "android": {"packageName":"com.example.appname","versionCode":1,"versionName":"1.0.0","androidPermissions":[${perms.map(p=>`"${p}"`).join(",")}],"minSdkVersion":21,"targetSdkVersion":34,"iconPath":"./assets/icon.png","splashPath":"./assets/splash.png"},
  "exportHistory": []
}

SCREEN shape: {"id":"str","name":"ScreenName","route":"/route","components":[ComponentBlock],"logic":[LogicNode],"isInitialScreen":bool}
COMPONENTBLOCK: {"id":"str","type":"ALLOWED_TYPE","props":{},"children":[],"styles":{},"eventBindings":[{"trigger":"onPress","handler":"navigateTo","params":{"target":"screenId"}}]}
ALLOWED COMPONENTS: ${allowedComponents}

RULES:
- Exactly ONE screen has isInitialScreen: true
- packageName must be reverse-DNS (e.g. com.company.appname), all lowercase, 3+ segments
- versionCode must be a positive integer
- minSdkVersion must be 21 or higher, targetSdkVersion must be 34 or higher
- Styles use numeric RN values only (no px, no CSS units)
- NavigationBarBlock must be first component in screen if used
- Generate 2-4 meaningful screens that match the app description
- Make globalState keys match the dataKey props used in ListBlock and InputBlock stateKey props
- Do NOT include PaymentBlock unless complexity is complex
- Respond with raw JSON only. Start with {. End with }.`;
}

/* Parse AI response */
function parseResponse(raw) {
  let cleaned = raw.trim()
    .replace(/^```json\s*/i,"").replace(/\s*```$/,"")
    .replace(/^```\s*/,"").replace(/\s*```$/,"")
    .replace(/^json\n/,"").trim();

  const parsed = JSON.parse(cleaned);
  if (typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Response must be a JSON object");

  const required = ["id","name","screens","android","navigation","theme","globalState"];
  for (const f of required) {
    if (!parsed[f]) throw new Error(`Missing required field: "${f}"`);
  }
  if (!Array.isArray(parsed.screens) || parsed.screens.length === 0)
    throw new Error("screens must be a non-empty array");
  if (!parsed.screens.some(s => s.isInitialScreen))
    throw new Error("No screen has isInitialScreen: true");
  if (!parsed.android.packageName)
    throw new Error("Missing android.packageName");

  // Sanitize component types
  const VALID_TYPES = new Set(["TextBlock","ButtonBlock","InputBlock","ListBlock","CardBlock",
    "ImageBlock","FormBlock","NavigationBarBlock","TabBarBlock","ModalBlock",
    "MapBlock","ChartBlock","AuthGateBlock","ApiDataBlock","PaymentBlock"]);
  function sanitizeComps(comps) {
    return (comps||[]).map(c => ({
      ...c,
      type: VALID_TYPES.has(c.type) ? c.type : "TextBlock",
      children: sanitizeComps(c.children),
    }));
  }
  parsed.screens = parsed.screens.map(s => ({...s, components: sanitizeComps(s.components)}));
  return parsed;
}

/* Validate project */
function validateProject(p) {
  const errors = [];
  if (!p.name?.trim())  errors.push("Project name is empty");
  if (!p.screens?.length) errors.push("No screens defined");
  if (!/^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*){2,}$/.test(p.android?.packageName||""))
    errors.push(`Invalid packageName: "${p.android?.packageName}" — must be reverse-DNS (com.x.y)`);
  if (!Number.isInteger(p.android?.versionCode) || p.android?.versionCode < 1)
    errors.push(`versionCode must be a positive integer (got: ${p.android?.versionCode})`);
  if ((p.android?.minSdkVersion||0) < 21)
    errors.push(`minSdkVersion must be ≥ 21 (got: ${p.android?.minSdkVersion})`);
  if ((p.android?.targetSdkVersion||0) < 34)
    errors.push(`targetSdkVersion must be ≥ 34 (got: ${p.android?.targetSdkVersion})`);
  return errors;
}

/* ── EXPENSE TRACKER — baked-in demo for full-cycle test ── */
const EXPENSE_TRACKER = {
  id:"expense-tracker-demo",
  name:"ExpenseTracker",
  description:"A simple Expense Tracker app with a dashboard and an Add Expense form",
  createdAt:"2026-04-16T10:00:00.000Z",
  updatedAt:"2026-04-16T10:00:00.000Z",
  version:1,
  complexity:"medium",
  screens:[
    {
      id:"s-dash", name:"DashboardScreen", route:"/dashboard", isInitialScreen:true, logic:[],
      components:[
        { id:"d1", type:"NavigationBarBlock", props:{title:"💰 Expenses"}, children:[], styles:{}, eventBindings:[] },
        { id:"d2", type:"CardBlock", props:{elevated:true}, children:[
          { id:"d2a", type:"TextBlock", props:{text:"Total Spent", variant:"label"}, children:[], styles:{}, eventBindings:[] },
          { id:"d2b", type:"TextBlock", props:{text:"$0.00", variant:"h1"}, children:[], styles:{color:"#34d399"}, eventBindings:[] },
        ], styles:{margin:"8px 16px"}, eventBindings:[] },
        { id:"d3", type:"TextBlock", props:{text:"Recent Expenses", variant:"h2"}, children:[], styles:{}, eventBindings:[] },
        { id:"d4", type:"ListBlock", props:{dataKey:"expenses", emptyStateText:"No expenses yet — add one below!"}, children:[], styles:{}, eventBindings:[] },
        { id:"d5", type:"ButtonBlock", props:{label:"＋ Add Expense", variant:"primary"}, children:[], styles:{}, eventBindings:[{trigger:"onPress",handler:"navigateTo",params:{target:"s-add"}}] },
      ],
    },
    {
      id:"s-add", name:"AddExpenseScreen", route:"/add", isInitialScreen:false, logic:[
        { id:"l1", trigger:"onMount", action:{type:"SET_STATE", key:"expenseAmount", value:""} },
        { id:"l2", trigger:"onMount", action:{type:"SET_STATE", key:"expenseLabel", value:""} },
      ],
      components:[
        { id:"a1", type:"NavigationBarBlock", props:{title:"New Expense", showBackButton:true}, children:[], styles:{}, eventBindings:[] },
        { id:"a2", type:"TextBlock", props:{text:"What did you spend on?", variant:"h2"}, children:[], styles:{}, eventBindings:[] },
        { id:"a3", type:"InputBlock", props:{placeholder:"e.g. Coffee, Groceries…", stateKey:"expenseLabel", label:"Description"}, children:[], styles:{}, eventBindings:[] },
        { id:"a4", type:"InputBlock", props:{placeholder:"0.00", stateKey:"expenseAmount", label:"Amount ($)", inputType:"number"}, children:[], styles:{}, eventBindings:[] },
        { id:"a5", type:"ButtonBlock", props:{label:"Save Expense", variant:"primary"}, children:[], styles:{}, eventBindings:[{trigger:"onPress",handler:"navigateTo",params:{target:"s-dash"}}] },
        { id:"a6", type:"ButtonBlock", props:{label:"Cancel", variant:"secondary"}, children:[], styles:{}, eventBindings:[{trigger:"onPress",handler:"navigateTo",params:{target:"s-dash"}}] },
      ],
    },
    {
      id:"s-history", name:"HistoryScreen", route:"/history", isInitialScreen:false, logic:[],
      components:[
        { id:"h1", type:"NavigationBarBlock", props:{title:"History", showBackButton:true}, children:[], styles:{}, eventBindings:[] },
        { id:"h2", type:"TextBlock", props:{text:"All Expenses", variant:"h2"}, children:[], styles:{}, eventBindings:[] },
        { id:"h3", type:"ListBlock", props:{dataKey:"expenses", emptyStateText:"No expense history yet."}, children:[], styles:{}, eventBindings:[] },
      ],
    },
  ],
  globalState:{ keys:{
    expenses:{type:"array",defaultValue:[{label:"Coffee",amount:"$4.50"},{label:"Groceries",amount:"$67.20"}],persistLocally:true},
    expenseLabel:{type:"string",defaultValue:"",persistLocally:false},
    expenseAmount:{type:"string",defaultValue:"",persistLocally:false},
    total:{type:"string",defaultValue:"$71.70",persistLocally:false},
  }},
  theme:{primaryColor:"#34d399",secondaryColor:"#10b981",backgroundColor:"#0a0f0c",textColor:"#e8f5ee",fontFamily:"System",borderRadius:"lg",darkMode:true},
  navigation:{type:"tab",tabs:[
    {label:"Dashboard",icon:"home",screenId:"s-dash"},
    {label:"Add",icon:"plus",screenId:"s-add"},
    {label:"History",icon:"list",screenId:"s-history"},
  ]},
  android:{packageName:"com.example.expensetracker",versionCode:1,versionName:"1.0.0",
    androidPermissions:[],minSdkVersion:21,targetSdkVersion:34,
    iconPath:"./assets/icon.png",splashPath:"./assets/splash.png"},
  exportHistory:[],
};

const TASKLIST = {
  id:"f4a3e2d1", name:"TaskList", description:"A simple task list app", complexity:"simple",
  screens:[
    { id:"s-home", name:"HomeScreen", route:"/home", isInitialScreen:true, logic:[],
      components:[
        { id:"c1",type:"NavigationBarBlock",props:{title:"My Tasks"},children:[],styles:{},eventBindings:[] },
        { id:"c2",type:"ListBlock",props:{dataKey:"tasks",emptyStateText:"No tasks yet! Tap + to add one."},children:[],styles:{},eventBindings:[] },
        { id:"c3",type:"ButtonBlock",props:{label:"＋ Add Task",variant:"primary"},children:[],styles:{},eventBindings:[{trigger:"onPress",handler:"navigateTo",params:{target:"s-add"}}] },
      ]},
    { id:"s-add", name:"AddTaskScreen", route:"/add", isInitialScreen:false, logic:[],
      components:[
        { id:"c4",type:"NavigationBarBlock",props:{title:"New Task",showBackButton:true},children:[],styles:{},eventBindings:[] },
        { id:"c5",type:"InputBlock",props:{placeholder:"What needs to be done?",stateKey:"newTask"},children:[],styles:{},eventBindings:[] },
        { id:"c6",type:"ButtonBlock",props:{label:"Save Task",variant:"primary"},children:[],styles:{},eventBindings:[{trigger:"onPress",handler:"navigateTo",params:{target:"s-home"}}] },
      ]},
  ],
  globalState:{keys:{tasks:{type:"array",defaultValue:[],persistLocally:true},newTask:{type:"string",defaultValue:"",persistLocally:false}}},
  theme:{primaryColor:"#f59e0b",secondaryColor:"#d97706",backgroundColor:"#0c0c0f",textColor:"#f1f0ee",fontFamily:"System",borderRadius:"md",darkMode:true},
  navigation:{type:"stack"},
  android:{packageName:"com.example.tasklist",versionCode:1,versionName:"1.0.0",
    androidPermissions:[],minSdkVersion:21,targetSdkVersion:34,
    iconPath:"./assets/icon.png",splashPath:"./assets/splash.png"},
  exportHistory:[],
};

/* ══════════════════════════════════════════════════════════════
   RN-WEB RENDERER  (theme-aware via `theme` prop)
══════════════════════════════════════════════════════════════ */
function RNComp({ c, gs, setGs, nav, theme }) {
  const p   = c.props || {};
  const eb  = c.eventBindings?.find(e => e.trigger === "onPress");
  const go  = () => eb?.params?.target && nav(eb.params.target);
  const pri = theme?.primaryColor || T.amber;
  const bg  = theme?.backgroundColor || T.bg;
  const tx  = theme?.textColor || T.text;

  switch (c.type) {

    case "NavigationBarBlock":
      return (
        <div style={{ display:"flex", alignItems:"center", gap:10, padding:"14px 16px",
          borderBottom:`1px solid ${T.border}`, flexShrink:0, background:bg }}>
          {p.showBackButton && (
            <button onClick={() => nav("__back")} style={{ background:"none", border:"none",
              color:pri, fontSize:22, cursor:"pointer", padding:"0 4px", lineHeight:1, marginLeft:-4 }}>‹</button>
          )}
          <span style={syne({ fontWeight:700, fontSize:17, color:tx, flex:1 })}>{p.title}</span>
        </div>
      );

    case "TextBlock": {
      const sz = p.variant==="h1"?26:p.variant==="h2"?19:p.variant==="caption"?12:p.variant==="label"?11:14;
      const fw = p.variant==="h1"||p.variant==="h2" ? 700 : p.variant==="label" ? 600 : 400;
      const cl = p.variant==="caption" ? T.text3 : p.variant==="label" ? pri : tx;
      const up = p.variant==="label" ? "uppercase" : "none";
      return <p style={{ ...sans({fontSize:sz,fontWeight:fw,color:cl,letterSpacing:p.variant==="label"?"0.06em":"normal"}),
        padding:"3px 16px", lineHeight:1.5, textTransform:up, ...c.styles }}>{p.text}</p>;
    }

    case "ButtonBlock": {
      const isPri = !p.variant || p.variant==="primary";
      return (
        <div style={{ padding:"6px 16px" }}>
          <button onClick={go} style={sans({ width:"100%", fontWeight:600, fontSize:15, cursor:"pointer",
            background: isPri ? `linear-gradient(135deg,${pri},${theme?.secondaryColor||pri})` : T.bg3,
            color: isPri ? "#0c0c0f" : T.text, border: isPri ? "none" : `1px solid ${T.border2}`,
            borderRadius:10, padding:"13px 18px",
            boxShadow: isPri ? `0 3px 16px ${pri}44` : "none", transition:"opacity .15s" })}
            onMouseEnter={e=>e.currentTarget.style.opacity=".82"}
            onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
            {p.label}
          </button>
        </div>
      );
    }

    case "InputBlock": {
      const val = gs[p.stateKey] ?? "";
      return (
        <div style={{ padding:"5px 16px" }}>
          {p.label && <div style={lbl({ marginBottom:5, color:T.text3 })}>{p.label}</div>}
          <input value={val} placeholder={p.placeholder} type={p.inputType||"text"}
            onChange={e => setGs(s=>({...s,[p.stateKey]:e.target.value}))}
            style={sans({ width:"100%", background:T.bg3, color:T.text,
              border:`1px solid ${T.border2}`, borderRadius:9, padding:"12px 14px", fontSize:14 })}
            onFocus={e=>e.target.style.borderColor=pri}
            onBlur={e=>e.target.style.borderColor=T.border2}/>
        </div>
      );
    }

    case "ListBlock": {
      const items = gs[p.dataKey] || [];
      return (
        <div style={{ flex:1, overflow:"auto", padding:"4px 16px" }}>
          {!items.length
            ? <p style={mono({fontSize:12,color:T.text3,textAlign:"center",paddingTop:32,lineHeight:1.7})}>
                {p.emptyStateText||"No items yet"}
              </p>
            : items.map((item,i) => {
                const label = typeof item==="object" ? (item.label||item.name||JSON.stringify(item)) : String(item);
                const sub   = typeof item==="object" && item.amount ? item.amount : null;
                return (
                  <div key={i} style={{ display:"flex",alignItems:"center",gap:10,
                    padding:"12px 0",borderBottom:`1px solid ${T.border}`,animation:"fi .2s ease" }}>
                    <div style={{ width:7,height:7,borderRadius:"50%",background:pri,flexShrink:0 }}/>
                    <span style={sans({fontSize:14,color:tx,flex:1})}>{label}</span>
                    {sub && <span style={mono({fontSize:12,color:pri})}>{sub}</span>}
                  </div>
                );
              })
          }
        </div>
      );
    }

    case "CardBlock":
      return (
        <div style={{ margin:"6px 16px", background:T.bg3, borderRadius:12, padding:14,
          border:`1px solid ${T.border2}`, boxShadow:"0 4px 20px rgba(0,0,0,.5)", ...c.styles }}>
          {c.children?.map(ch=><RNComp key={ch.id} c={ch} gs={gs} setGs={setGs} nav={nav} theme={theme}/>)}
        </div>
      );

    case "FormBlock":
      return (
        <div style={{ padding:"5px 16px", display:"flex", flexDirection:"column", gap:6 }}>
          {c.children?.map(ch=><RNComp key={ch.id} c={ch} gs={gs} setGs={setGs} nav={nav} theme={theme}/>)}
          <button onClick={go} style={sans({fontWeight:600,fontSize:14,cursor:"pointer",
            background:`linear-gradient(135deg,${pri},${theme?.secondaryColor||pri})`,
            color:"#0c0c0f",border:"none",borderRadius:9,padding:"12px 16px"})}>
            {p.submitLabel||"Submit"}
          </button>
        </div>
      );

    case "ImageBlock":
      return <div style={{padding:"4px 16px"}}>
        <img src={p.src} alt={p.alt||""} style={{width:p.width||"100%",height:p.height||160,
          objectFit:p.resizeMode||"cover",borderRadius:9,display:"block"}}/></div>;

    case "ApiDataBlock":
      return <div style={{margin:"5px 16px",padding:"9px 12px",background:"#0e1e18",
        border:`1px solid ${T.green}33`,borderRadius:8}}>
        <span style={mono({fontSize:11,color:T.green})}>⬡ API: {p.method||"GET"} {p.url}</span></div>;

    case "AuthGateBlock":
      return <div style={{margin:"5px 16px",padding:"9px 12px",background:"#0e1428",
        border:`1px solid ${T.blue}33`,borderRadius:8}}>
        <span style={mono({fontSize:11,color:T.blue})}>⬡ Auth Gate → {p.redirectOnFail}</span></div>;

    case "MapBlock":
      return <div style={{margin:"6px 16px",height:130,background:T.bg3,borderRadius:8,
        display:"flex",alignItems:"center",justifyContent:"center",border:`1px solid ${T.border2}`}}>
        <span style={mono({fontSize:12,color:T.text3})}>◈ Map ({p.latitude},{p.longitude})</span></div>;

    case "ChartBlock":
      return <div style={{margin:"6px 16px",height:110,background:T.bg3,borderRadius:8,
        display:"flex",alignItems:"center",justifyContent:"center",border:`1px solid ${T.border2}`}}>
        <span style={mono({fontSize:12,color:T.text3})}>◈ {p.chartType||"bar"} chart · {p.dataKey}</span></div>;

    case "PaymentBlock":
      return <div style={{margin:"6px 16px",padding:13,background:"#1a1510",
        border:`1px solid ${T.amber}33`,borderRadius:9}}>
        <div style={mono({fontSize:12,color:T.amber,marginBottom:5})}>⬡ Pay: {p.productName}</div>
        <div style={sans({fontSize:12,color:T.text3})}>{p.provider} · {p.currency} {p.amount}</div></div>;

    case "NavigationBarBlock": return null;
    case "TabBarBlock": return null;
    default: return null;
  }
}

function RNScreen({ screen, project, onNavigate }) {
  const initGs = () => {
    const s = {};
    for (const [k,v] of Object.entries(project.globalState?.keys||{})) s[k]=v.defaultValue;
    return s;
  };
  const [gs,setGs]     = useState(initGs);
  const [hist,setHist] = useState([screen.id]);

  // Re-init global state when project changes (e.g. after generation)
  useEffect(() => { setGs(initGs()); }, [project.id]);

  const nav = useCallback(target => {
    if (target === "__back") {
      if (hist.length > 1) { const n=hist.slice(0,-1); setHist(n); onNavigate(n[n.length-1]); }
      return;
    }
    const found = project.screens.find(s=>s.id===target||s.route===target);
    if (found) { setHist(h=>[...h,found.id]); onNavigate(found.id); }
  }, [hist,project,onNavigate]);

  const bar  = screen.components.find(c=>c.type==="NavigationBarBlock");
  const body = screen.components.filter(c=>c.type!=="NavigationBarBlock");
  const { theme } = project;

  return (
    <div style={{ display:"flex",flexDirection:"column",height:"100%",
      background:theme?.backgroundColor||T.bg,overflow:"hidden" }}>
      {bar && <RNComp c={bar} gs={gs} setGs={setGs} nav={nav} theme={theme}/>}
      <div style={{ flex:1,overflowY:"auto",display:"flex",flexDirection:"column",
        gap:4,paddingTop:6,paddingBottom:16 }}>
        {body.map(c=><RNComp key={c.id} c={c} gs={gs} setGs={setGs} nav={nav} theme={theme}/>)}
      </div>
      {/* Tab bar simulation */}
      {project.navigation?.type==="tab" && project.navigation?.tabs && (
        <div style={{ display:"flex",borderTop:`1px solid ${T.border}`,background:T.bg2,flexShrink:0 }}>
          {project.navigation.tabs.map(tab=>{
            const s=project.screens.find(x=>x.id===tab.screenId);
            const active=s?.id===screen.id;
            return (
              <button key={tab.screenId} onClick={()=>nav(tab.screenId)}
                style={{ flex:1,padding:"10px 4px",background:"transparent",border:"none",
                  cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:3 }}>
                <span style={{ fontSize:16 }}>
                  {tab.icon==="home"?"⌂":tab.icon==="plus"?"＋":tab.icon==="list"?"≡":"○"}
                </span>
                <span style={mono({fontSize:9,color:active?theme?.primaryColor||T.amber:T.text3})}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ── Phone frame at 0.75× scale ── */
function PhoneFrame({ project, activeScreenId, onScreenChange }) {
  const cur = project.screens.find(s=>s.id===activeScreenId)||project.screens[0];
  const SCALE = 0.75;
  const W = 300, H = 580;
  const pri = project.theme?.primaryColor || T.amber;

  return (
    <div style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:10 }}>
      {/* Scale container — negative margin collapses the empty scaled space */}
      <div style={{ position:"relative",
        width:W*SCALE, height:H*SCALE+44+18,
        transformOrigin:"top left" }}>
        <div style={{ transformOrigin:"top left", transform:`scale(${SCALE})`,
          width:W, position:"absolute",top:0,left:0 }}>
          {/* Chrome */}
          <div style={{ width:W, background:"#141420", borderRadius:44, padding:9,
            boxShadow:`0 0 0 1.5px ${T.border2}, 0 24px 64px rgba(0,0,0,.8), inset 0 1.5px 0 #383860` }}>
            <div style={{ height:26,display:"flex",alignItems:"center",justifyContent:"center",position:"relative" }}>
              <div style={{ width:80,height:8,background:T.bg,borderRadius:5 }}/>
              <div style={{ position:"absolute",right:26,width:7,height:7,borderRadius:"50%",background:T.border2 }}/>
            </div>
            <div style={{ height:H,background:project.theme?.backgroundColor||T.bg,
              borderRadius:28,overflow:"hidden" }}>
              <RNScreen key={`${project.id}-${cur.id}`} screen={cur} project={project} onNavigate={onScreenChange}/>
            </div>
            <div style={{ height:22,display:"flex",alignItems:"center",justifyContent:"center" }}>
              <div style={{ width:80,height:4,background:T.border2,borderRadius:2 }}/>
            </div>
          </div>
        </div>
      </div>

      {/* Screen pills */}
      <div style={{ display:"flex",gap:6,flexWrap:"wrap",justifyContent:"center" }}>
        {project.screens.map(s=>{
          const active=s.id===activeScreenId;
          return (
            <button key={s.id} onClick={()=>onScreenChange(s.id)}
              style={mono({fontSize:10,padding:"4px 12px",borderRadius:20,
                background:active?pri:T.bg3, color:active?"#0c0c0f":T.text3,
                border:`1px solid ${active?pri:T.border}`,cursor:"pointer",transition:"all .15s"})}>
              {s.name}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ── Status pipeline ── */
const PIPE_STEPS = [
  {id:"analyzing",  label:"Analyze"},
  {id:"generating", label:"Generate"},
  {id:"parsing",    label:"Parse"},
  {id:"validating", label:"Validate"},
  {id:"success",    label:"Done"},
];
const PIPE_IDS = PIPE_STEPS.map(s=>s.id);

function Pipeline({ status, errorMsg, onRetry, prompt }) {
  if (status==="idle") return null;
  const ai = PIPE_IDS.indexOf(status);
  const isErr = status==="error";

  return (
    <div style={{ display:"flex",flexDirection:"column",gap:8,marginTop:12,animation:"fi .3s ease" }}>
      {/* Step dots */}
      <div style={{ display:"flex",alignItems:"center" }}>
        {PIPE_STEPS.map((st,i)=>{
          const done   = i<ai||status==="success";
          const active = PIPE_IDS[i]===status&&status!=="success";
          const col    = done||active ? T.amber : T.border;
          return (
            <div key={i} style={{ flex:1,display:"flex",alignItems:"center" }}>
              {i>0&&<div style={{ flex:1,height:1.5,background:done?T.amber:T.border }}/>}
              <div style={{ position:"relative",flexShrink:0 }}>
                <div style={{ width:11,height:11,borderRadius:"50%",
                  background:done||active?T.amber:T.bg,
                  border:`2px solid ${col}`,
                  boxShadow:active?`0 0 12px ${T.amber}99`:"none",
                  animation:active?"pdot 1s ease-in-out infinite":"none",
                  transition:"all .3s" }}/>
                {active && (
                  <div style={{ position:"absolute",inset:-3,borderRadius:"50%",
                    border:`1.5px solid ${T.amber}66`,
                    animation:"pulse-ring .9s ease-out infinite" }}/>
                )}
              </div>
              {i<PIPE_STEPS.length-1&&<div style={{ flex:1,height:1.5,background:done?T.amber:T.border }}/>}
            </div>
          );
        })}
      </div>
      {/* Labels */}
      <div style={{ display:"flex" }}>
        {PIPE_STEPS.map((st,i)=>{
          const done   = i<ai||status==="success";
          const active = PIPE_IDS[i]===status&&status!=="success";
          return (
            <span key={i} style={mono({ flex:1,fontSize:9,
              color:done||active?T.amber:T.text4,
              textAlign:i===0?"left":i===PIPE_STEPS.length-1?"right":"center",
              fontWeight:active?"600":"400" })}>
              {st.label}
            </span>
          );
        })}
      </div>
      {/* Success banner */}
      {status==="success" && (
        <div style={{ display:"flex",alignItems:"center",gap:8,padding:"9px 12px",
          background:T.greenDim,border:`1px solid ${T.green}44`,borderRadius:8,animation:"fi .3s ease" }}>
          <span style={{ color:T.green,fontSize:14 }}>✓</span>
          <span style={sans({fontSize:13,color:T.green,fontWeight:500})}>App generated successfully</span>
        </div>
      )}
      {/* Error banner + retry */}
      {isErr && (
        <div style={{ padding:"12px 14px",background:T.redDim,
          border:`1px solid ${T.red}44`,borderRadius:9,animation:"fi .3s ease" }}>
          <div style={{ display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:10 }}>
            <div>
              <div style={sans({fontWeight:600,fontSize:13,color:T.red,marginBottom:5})}>
                ✗ Generation failed
              </div>
              <div style={mono({fontSize:11,color:`${T.red}cc`,lineHeight:1.6})}>
                {errorMsg||"An unexpected error occurred. Check your prompt and try again."}
              </div>
            </div>
            <button onClick={onRetry}
              style={mono({fontSize:11,padding:"7px 14px",borderRadius:7,flexShrink:0,
                background:T.redDim,color:T.red,border:`1px solid ${T.red}44`,
                cursor:"pointer",transition:"all .15s",fontWeight:600})}
              onMouseEnter={e=>e.currentTarget.style.background=`${T.red}35`}
              onMouseLeave={e=>e.currentTarget.style.background=T.redDim}>
              ↺ Retry
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   THEME EDITOR
══════════════════════════════════════════════════════════════ */
function ThemeEditor({ theme, onChange }) {
  const ColorSwatch = ({ label: lb, field }) => (
    <div style={{ display:"flex",flexDirection:"column",gap:5 }}>
      <span style={lbl()}>{lb}</span>
      <div style={{ display:"flex",alignItems:"center",gap:8 }}>
        <input type="color" value={theme[field]||"#000000"}
          onChange={e => onChange({...theme,[field]:e.target.value})}
          style={{ width:36,height:36,borderRadius:8,border:`1px solid ${T.border2}`,
            padding:2,background:"transparent",cursor:"pointer" }}/>
        <span style={mono({fontSize:11,color:T.text3})}>{theme[field]||"—"}</span>
      </div>
    </div>
  );

  return (
    <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
        <ColorSwatch label="Primary Color"     field="primaryColor"/>
        <ColorSwatch label="Secondary Color"   field="secondaryColor"/>
        <ColorSwatch label="Background Color"  field="backgroundColor"/>
        <ColorSwatch label="Text Color"        field="textColor"/>
      </div>
      <div>
        <span style={lbl({marginBottom:6,display:"block"})}>Dark Mode</span>
        <button onClick={() => onChange({...theme,darkMode:!theme.darkMode})}
          style={{ display:"flex",alignItems:"center",gap:8,padding:"7px 12px",
            background:theme.darkMode?`${T.amber}18`:T.bg3,
            border:`1px solid ${theme.darkMode?`${T.amber}44`:T.border}`,
            borderRadius:7,cursor:"pointer",transition:"all .2s" }}>
          <div style={{ width:32,height:17,borderRadius:9,background:theme.darkMode?T.amber:T.border2,
            position:"relative",transition:"background .2s" }}>
            <div style={{ position:"absolute",top:2,transition:"left .2s",
              left:theme.darkMode?16:2,width:13,height:13,borderRadius:"50%",background:"#fff" }}/>
          </div>
          <span style={mono({fontSize:10,color:theme.darkMode?T.amber:T.text3})}>
            {theme.darkMode?"Dark Mode ON":"Light Mode"}
          </span>
        </button>
      </div>
      <div style={{ padding:"9px 11px",background:T.bg,borderRadius:8,
        border:`1px solid ${T.border}`,display:"flex",alignItems:"center",gap:10 }}>
        <div style={{ width:24,height:24,borderRadius:6,
          background:`linear-gradient(135deg,${theme.primaryColor||T.amber},${theme.secondaryColor||T.amber2})` }}/>
        <div style={{ flex:1 }}>
          <div style={sans({fontSize:12,color:T.text,fontWeight:500})}>Preview</div>
          <div style={mono({fontSize:10,color:T.text3})}>{theme.primaryColor} → {theme.backgroundColor}</div>
        </div>
        <span style={{...pill(theme.darkMode?T.amber:T.blue), fontSize:10}}>
          {theme.darkMode?"dark":"light"}
        </span>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   EXPORT MODAL
══════════════════════════════════════════════════════════════ */
const EXPORT_FMTS = [
  {id:"raw-rn",          label:"Raw React Native", icon:"⬡", badge:"Flexible",    bc:T.blue,
   files:["App.tsx","src/screens/*.tsx","package.json","tsconfig.json","babel.config.js","README.md"]},
  {id:"expo-managed",    label:"Expo Managed",     icon:"◈", badge:"Recommended", bc:T.green,
   files:["App.tsx","src/screens/*.tsx","app.json","package.json","tsconfig.json","babel.config.js","assets/.gitkeep","README.md"]},
  {id:"expo-play-store", label:"Expo + Play Store", icon:"▲", badge:"Production",  bc:T.amber,
   files:["App.tsx","src/screens/*.tsx","app.json","eas.json","package.json","tsconfig.json","babel.config.js","assets/.gitkeep","README.md","SUBMIT_TO_PLAY_STORE.md"]},
];

function ExportModal({ project, onClose }) {
  const [sel,  setSel]  = useState("expo-play-store");
  const [done, setDone] = useState(false);
  const fmt = EXPORT_FMTS.find(f=>f.id===sel);
  const a   = project.android;

  const checks = [
    {k:"Package name",    ok:/^[a-z][a-z0-9]*(\.[a-z][a-z0-9]*){2,}$/.test(a.packageName||""), detail:a.packageName},
    {k:"Version code",    ok:Number.isInteger(a.versionCode)&&a.versionCode>=1,   detail:`versionCode: ${a.versionCode}`},
    {k:"Version name",    ok:!!(a.versionName),   detail:a.versionName||"missing"},
    {k:"Min SDK ≥ 21",   ok:a.minSdkVersion>=21,  detail:`minSdk: ${a.minSdkVersion}`},
    {k:"Target SDK ≥ 34",ok:a.targetSdkVersion>=34,detail:`targetSdk: ${a.targetSdkVersion}`},
    {k:"app.json",        ok:sel!=="raw-rn",        detail:sel!=="raw-rn"?"✓ generated":"N/A for raw-rn"},
    {k:"eas.json",        ok:sel==="expo-play-store",detail:sel==="expo-play-store"?"✓ generated":"N/A"},
    {k:"Icon path",       ok:!!(a.iconPath),        detail:a.iconPath||"⚠ not set"},
    {k:"Splash",          ok:!!(a.splashPath),       detail:a.splashPath||"⚠ advisory"},
  ];
  const blocking = checks.filter(c=>!c.ok&&c.k!=="Splash");

  return (
    <div style={{ position:"fixed",inset:0,zIndex:999,display:"flex",alignItems:"center",
      justifyContent:"center",background:"rgba(0,0,0,.82)",backdropFilter:"blur(8px)" }}
      onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div style={{ width:"min(680px,96vw)",maxHeight:"88vh",display:"flex",flexDirection:"column",
        background:"#111120",borderRadius:16,border:`1px solid ${T.border2}`,
        boxShadow:"0 32px 90px rgba(0,0,0,.9)",animation:"mi .2s ease" }}>

        <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",
          padding:"18px 22px 14px",borderBottom:`1px solid ${T.border}`,flexShrink:0 }}>
          <div>
            <div style={syne({fontWeight:800,fontSize:17,color:T.text})}>Export Project</div>
            <div style={mono({fontSize:11,color:T.text3,marginTop:3})}>
              {project.name} · {project.screens.length} screens · {project.complexity} · {a.packageName}
            </div>
          </div>
          <button onClick={onClose} style={{ width:30,height:30,background:T.bg3,
            border:`1px solid ${T.border2}`,borderRadius:7,cursor:"pointer",color:T.text2,
            fontSize:16,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
        </div>

        <div style={{ flex:1,overflowY:"auto",padding:"18px 22px",display:"flex",flexDirection:"column",gap:16 }}>
          {/* Format cards */}
          <div>
            <div style={{...lbl(),marginBottom:10}}>Select format</div>
            <div style={{ display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8 }}>
              {EXPORT_FMTS.map(f=>(
                <button key={f.id} onClick={()=>{setSel(f.id);setDone(false);}}
                  style={{ textAlign:"left",padding:"12px 13px",borderRadius:10,cursor:"pointer",
                    background:sel===f.id?T.bg3:T.bg2,
                    border:`1.5px solid ${sel===f.id?`${f.bc}aa`:T.border}`,
                    transition:"all .15s" }}>
                  <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:5 }}>
                    <span style={syne({fontSize:12,fontWeight:700,color:sel===f.id?T.text:T.text2})}>
                      {f.icon} {f.label}
                    </span>
                    <span style={pill(f.bc)}>{f.badge}</span>
                  </div>
                  <div style={mono({fontSize:10,color:T.text3})}>{f.files.length} files</div>
                </button>
              ))}
            </div>
          </div>

          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:12 }}>
            <div>
              <div style={{...lbl(),marginBottom:8}}>Files in ZIP — {fmt.files.length} total</div>
              <div style={{ background:T.bg,borderRadius:8,border:`1px solid ${T.border}`,
                padding:"10px 12px",display:"flex",flexDirection:"column",gap:5 }}>
                {fmt.files.map(f=>(
                  <div key={f} style={{ display:"flex",alignItems:"center",gap:8 }}>
                    <span style={{color:T.green,fontSize:11}}>✓</span>
                    <span style={mono({fontSize:11,color:T.text2})}>{f}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div style={{...lbl(),marginBottom:8}}>
                {sel==="expo-play-store"?"▲ Play Store Readiness":"Android Config"}
              </div>
              <div style={{ background:T.bg,borderRadius:8,border:`1px solid ${T.border}`,
                padding:"10px 12px",display:"flex",flexDirection:"column",gap:5 }}>
                {checks.map(c=>(
                  <div key={c.k} style={{ display:"flex",alignItems:"flex-start",gap:6 }}>
                    <span style={{fontSize:11,color:c.ok?T.green:T.red,flexShrink:0,marginTop:1}}>
                      {c.ok?"✓":"✗"}
                    </span>
                    <div style={{ minWidth:0 }}>
                      <span style={mono({fontSize:10,color:c.ok?T.text2:T.red})}>{c.k} </span>
                      <span style={mono({fontSize:10,color:T.text3})}>
                        {String(c.detail).slice(0,30)}{String(c.detail).length>30?"…":""}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {sel==="expo-play-store"&&blocking.length>0&&(
            <div style={{ background:"#1c0a0a",border:`1px solid ${T.red}44`,borderRadius:9,padding:"12px 14px" }}>
              <div style={mono({fontSize:11,color:T.red,marginBottom:5})}>
                ✗ {blocking.length} issue{blocking.length>1?"s":""} must be resolved
              </div>
              {blocking.map(e=><div key={e.k} style={mono({fontSize:11,color:`${T.red}88`,paddingLeft:12})}>
                • {e.k}: {e.detail}</div>)}
            </div>
          )}

          {done&&(
            <div style={{ background:T.greenDim,border:`1px solid ${T.green}44`,borderRadius:9,
              padding:"13px 15px",animation:"fi .3s ease" }}>
              <div style={sans({fontWeight:600,fontSize:13,color:T.green,marginBottom:3})}>
                ✓ {project.name}-{sel}.zip prepared for download
              </div>
              <div style={mono({fontSize:11,color:`${T.green}99`})}>
                {fmt.files.length} files · {a.packageName} · v{a.versionName} (build {a.versionCode})
              </div>
            </div>
          )}
        </div>

        <div style={{ padding:"14px 22px",borderTop:`1px solid ${T.border}`,
          display:"flex",gap:10,justifyContent:"flex-end",flexShrink:0 }}>
          <button onClick={onClose} style={mono({fontSize:11,padding:"9px 18px",
            background:T.bg3,color:T.text2,border:`1px solid ${T.border2}`,
            borderRadius:8,cursor:"pointer"})}>Cancel</button>
          <button disabled={sel==="expo-play-store"&&blocking.length>0}
            onClick={()=>setDone(true)}
            style={syne({fontWeight:700,fontSize:11,letterSpacing:"0.06em",padding:"9px 22px",
              borderRadius:8,border:"none",
              cursor:sel==="expo-play-store"&&blocking.length>0?"not-allowed":"pointer",
              background:sel==="expo-play-store"&&blocking.length>0?T.bg3:`linear-gradient(135deg,${fmt.bc},${fmt.bc}cc)`,
              color:sel==="expo-play-store"&&blocking.length>0?T.text3:"#0c0c0f",
              boxShadow:!(sel==="expo-play-store"&&blocking.length>0)?`0 3px 16px ${fmt.bc}55`:"none"})}>
            {done?"✓ Downloaded":`↓ DOWNLOAD ${fmt.label.toUpperCase()} ZIP`}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   ANDROID INSPECTOR
══════════════════════════════════════════════════════════════ */
function AndroidInspector({ project, onUpdate }) {
  const [ed,setEd] = useState(false);
  const [dr,setDr] = useState(null);
  const a = ed ? dr : project.android;

  const Field = ({ label: lb, k, type="text" }) => (
    <div style={{ display:"flex",flexDirection:"column",gap:4 }}>
      <span style={lbl()}>{lb}</span>
      {ed
        ?<input type={type} value={a[k]??""} onChange={e=>setDr(d=>({...d,[k]:type==="number"?Number(e.target.value):e.target.value}))}
            style={mono({fontSize:12,background:T.bg,color:T.text,border:`1px solid ${T.amber}55`,borderRadius:7,padding:"8px 11px"})}/>
        :<span style={mono({fontSize:12,color:T.text,background:T.bg,padding:"8px 11px",borderRadius:7,
            border:`1px solid ${T.border}`,wordBreak:"break-all"})}>{String(a[k]??"")}</span>}
    </div>
  );

  return (
    <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
      <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
        <span style={lbl()}>Android Config</span>
        {!ed
          ?<button onClick={()=>{setDr({...project.android});setEd(true);}}
              style={mono({fontSize:10,padding:"4px 10px",background:T.bg3,color:T.amber,
                border:`1px solid ${T.amber}44`,borderRadius:6,cursor:"pointer"})}>EDIT</button>
          :<div style={{ display:"flex",gap:6 }}>
              <button onClick={()=>{onUpdate(dr);setEd(false);}} style={mono({fontSize:10,padding:"4px 10px",
                background:T.greenDim,color:T.green,border:`1px solid ${T.green}44`,borderRadius:6,cursor:"pointer"})}>SAVE</button>
              <button onClick={()=>setEd(false)} style={mono({fontSize:10,padding:"4px 10px",
                background:T.redDim,color:T.red,border:`1px solid ${T.red}44`,borderRadius:6,cursor:"pointer"})}>CANCEL</button>
            </div>}
      </div>
      <Field label="Package Name" k="packageName"/>
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
        <Field label="Version Code" k="versionCode" type="number"/>
        <Field label="Version Name" k="versionName"/>
      </div>
      <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8 }}>
        <Field label="Min SDK" k="minSdkVersion" type="number"/>
        <Field label="Target SDK" k="targetSdkVersion" type="number"/>
      </div>
      <div>
        <div style={{...lbl(),marginBottom:6}}>Permissions</div>
        <div style={{ display:"flex",flexWrap:"wrap",gap:5,padding:"9px 11px",
          background:T.bg,borderRadius:7,border:`1px solid ${T.border}`,minHeight:34 }}>
          {!a.androidPermissions?.length
            ?<span style={mono({fontSize:11,color:T.text4})}>none — minimum footprint ✓</span>
            :a.androidPermissions.map(p=><span key={p} style={pill(T.amber)}>{p}</span>)}
        </div>
      </div>
      <div style={{ display:"flex",alignItems:"center",gap:8 }}>
        <span style={lbl()}>Complexity</span>
        <span style={pill(project.complexity==="simple"?T.green:project.complexity==="medium"?T.blue:T.amber,
          {textTransform:"uppercase"})}>{project.complexity}</span>
        <span style={lbl()}>{project.screens.length} screens</span>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   LICENSE / SETTINGS HELPERS
══════════════════════════════════════════════════════════════ */

/* Stripe payment page */
const STORE_URL = "https://metaforge.lemonsqueezy.com"; // ← replace with your Lemon Squeezy store URL

/* Read/write from localStorage safely (no-op in SSR/sandboxes) */
function lsGet(k, fallback="") {
  try { return localStorage.getItem(k) || fallback; } catch { return fallback; }
}
function lsSet(k, v) {
  try { localStorage.setItem(k, v); } catch {}
}

function isLicenseValid(key) {
  if (!key || !key.trim()) return false;
  // Lemon Squeezy license keys are alphanumeric strings, typically 10-32 chars
  return /^[a-zA-Z0-9_-]{8,64}$/.test(key.trim());
}

/* ══════════════════════════════════════════════════════════════
   SETTINGS & ACTIVATION MODAL
══════════════════════════════════════════════════════════════ */
function SettingsModal({ onClose, onSave }) {
  const [apiKey,     setApiKey]     = useState(() => lsGet("mf_api_key"));
  const [licenseKey, setLicenseKey] = useState(() => lsGet("mf_license_key"));
  const [saved,      setSaved]      = useState(false);
  const [showApi,    setShowApi]    = useState(false);

  const valid    = isLicenseValid(licenseKey);
  

  function handleSave() {
    lsSet("mf_api_key",     apiKey.trim());
    lsSet("mf_license_key", licenseKey.trim());
    setSaved(true);
    setTimeout(() => { onSave(apiKey.trim(), licenseKey.trim()); onClose(); }, 900);
  }

  const inputStyle = (accent=T.border2) => mono({
    width:"100%", fontSize:13, background:T.bg, color:T.text,
    border:`1px solid ${accent}`, borderRadius:8, padding:"11px 14px",
  });

  return (
    <div style={{ position:"fixed",inset:0,zIndex:999,display:"flex",alignItems:"center",
      justifyContent:"center",background:"rgba(0,0,0,.85)",backdropFilter:"blur(10px)" }}
      onClick={e=>e.target===e.currentTarget&&onClose()}>

      <div style={{ width:"min(560px,95vw)",display:"flex",flexDirection:"column",
        background:"#0f0f1a",borderRadius:16,border:`1px solid ${T.border2}`,
        boxShadow:"0 32px 90px rgba(0,0,0,.95)",animation:"mi .2s ease",overflow:"hidden" }}>

        {/* ── Header ── */}
        <div style={{ padding:"20px 24px 16px",borderBottom:`1px solid ${T.border}`,
          background:"linear-gradient(135deg,#0f0f1a,#1a1028)" }}>
          <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
            <div style={{ display:"flex",alignItems:"center",gap:12 }}>
              <div style={{ width:36,height:36,borderRadius:10,
                background:`linear-gradient(135deg,${T.amber},${T.amber2})`,
                display:"flex",alignItems:"center",justifyContent:"center",
                boxShadow:`0 0 18px ${T.amber}66` }}>
                <span style={{ fontSize:18 }}>⚙</span>
              </div>
              <div>
                <div style={syne({fontWeight:800,fontSize:16,color:T.text})}>Settings & Activation</div>
                <div style={mono({fontSize:10,color:T.text3,marginTop:2})}>MetaForge Pro · $35 one-time</div>
              </div>
            </div>
            <button onClick={onClose} style={{ width:30,height:30,background:T.bg3,
              border:`1px solid ${T.border2}`,borderRadius:7,cursor:"pointer",color:T.text2,
              fontSize:16,display:"flex",alignItems:"center",justifyContent:"center" }}>×</button>
          </div>
        </div>

        {/* ── Body ── */}
        <div style={{ padding:"22px 24px",display:"flex",flexDirection:"column",gap:18 }}>

          {/* License key */}
          <div style={{ display:"flex",flexDirection:"column",gap:7 }}>
            <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
              <span style={lbl()}>License Key</span>
              {valid && (
                <span style={pill(T.green)}>
                  {"✓ Active"}
                </span>
              )}
            </div>
            <input
              value={licenseKey}
              onChange={e=>{setLicenseKey(e.target.value);setSaved(false);}}
              placeholder="MF-XXXX-XXXX-XXXX"
              style={inputStyle(valid ? T.green : licenseKey.trim() ? T.red : T.border2)}
              onFocus={e=>e.target.style.borderColor=T.amber}
              onBlur={e=>e.target.style.borderColor=valid?T.green:licenseKey.trim()?T.red:T.border2}
            />
            {!valid && licenseKey.trim() && (
              <span style={mono({fontSize:11,color:T.red})}>
                ✗ Invalid license key format
              </span>
            )}
            {!licenseKey.trim() && (
              <div style={{ display:"flex",alignItems:"center",gap:10 }}>
                <span style={mono({fontSize:11,color:T.text3})}>Don't have a key?</span>
                <button onClick={()=>window.open(STORE_URL,"_blank")}
                  style={syne({fontSize:11,fontWeight:700,padding:"5px 14px",borderRadius:7,
                    background:`linear-gradient(135deg,${T.amber},${T.amber2})`,
                    color:"#0c0c0f",border:"none",cursor:"pointer",
                    boxShadow:`0 2px 12px ${T.amber}55`,letterSpacing:"0.05em"})}>
                  Buy MetaForge Pro →
                </button>
              </div>
            )}
          </div>

          {/* Divider */}
          <div style={{ height:1,background:T.border }}/>

          {/* API Key */}
          <div style={{ display:"flex",flexDirection:"column",gap:7 }}>
            <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between" }}>
              <span style={lbl()}>Anthropic API Key</span>
              <a href="https://console.anthropic.com/settings/keys" target="_blank"
                style={mono({fontSize:10,color:T.blue,textDecoration:"none"})}>
                Get key → anthropic.com
              </a>
            </div>
            <div style={{ position:"relative" }}>
              <input
                value={apiKey} type={showApi?"text":"password"}
                onChange={e=>{setApiKey(e.target.value);setSaved(false);}}
                placeholder="sk-ant-api03-…"
                style={{...inputStyle(apiKey?"#f59e0b44":T.border2),paddingRight:44}}
                onFocus={e=>e.target.style.borderColor=`${T.amber}88`}
                onBlur={e=>e.target.style.borderColor=apiKey?"#f59e0b44":T.border2}
              />
              <button onClick={()=>setShowApi(v=>!v)}
                style={{ position:"absolute",right:12,top:"50%",transform:"translateY(-50%)",
                  background:"none",border:"none",cursor:"pointer",color:T.text3,fontSize:14 }}>
                {showApi?"🙈":"👁"}
              </button>
            </div>
            <span style={mono({fontSize:10,color:T.text3,lineHeight:1.6})}>
              Your key is stored only in your browser's localStorage — never sent to our servers.
            </span>
          </div>

          {/* Saved banner */}
          {saved && (
            <div style={{ padding:"10px 14px",background:T.greenDim,
              border:`1px solid ${T.green}44`,borderRadius:8,animation:"fi .3s ease" }}>
              <span style={mono({fontSize:12,color:T.green})}>✓ Settings saved — activating…</span>
            </div>
          )}
        </div>

        {/* ── Footer ── */}
        <div style={{ padding:"14px 24px",borderTop:`1px solid ${T.border}`,
          display:"flex",gap:10,justifyContent:"flex-end" }}>
          <button onClick={onClose}
            style={mono({fontSize:11,padding:"9px 18px",background:T.bg3,
              color:T.text2,border:`1px solid ${T.border2}`,borderRadius:8,cursor:"pointer"})}>
            Cancel
          </button>
          <button onClick={handleSave} disabled={!valid || !apiKey.trim()}
            style={syne({fontWeight:700,fontSize:11,letterSpacing:"0.06em",
              padding:"9px 22px",borderRadius:8,border:"none",
              cursor:valid&&apiKey.trim()?"pointer":"not-allowed",
              background:valid&&apiKey.trim()?`linear-gradient(135deg,${T.amber},${T.amber2})`:T.bg3,
              color:valid&&apiKey.trim()?"#0c0c0f":T.text3,
              boxShadow:valid&&apiKey.trim()?`0 3px 14px ${T.amber}55`:"none"})}>
            Save & Activate
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   QUICK START GUIDE
══════════════════════════════════════════════════════════════ */
function QuickStartGuide({ onOpenSettings }) {
  const steps = [
    {
      n:"01", color:T.amber, title:"Buy your license",
      body:"One-time $35 payment. Instant license key delivery to your email.",
      cta:"Buy Now → MetaForge Pro", url:STORE_URL,
    },
    {
      n:"02", color:T.blue, title:"Get your Anthropic API key",
      body:"Sign up free at Anthropic.com. Your key powers the AI generation engine.",
      cta:"console.anthropic.com →", url:"https://console.anthropic.com/settings/keys",
    },
    {
      n:"03", color:T.green, title:"Enter key & license in Settings",
      body:"Click ⚙ Settings in the top bar. Paste both keys and hit Save & Activate.",
      cta:"Open Settings", action: onOpenSettings,
    },
    {
      n:"04", color:T.violet, title:"Start building Google Play apps",
      body:"Describe any app in plain English. MetaForge builds, previews, and packages it — ready for the Play Store.",
      cta:null,
    },
  ];

  return (
    <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
      <div style={{ padding:"11px 13px",background:`${T.violet}14`,
        border:`1px solid ${T.violet}33`,borderRadius:9,
        display:"flex",alignItems:"center",gap:10 }}>
        <span style={{ fontSize:16 }}>🚀</span>
        <span style={sans({fontSize:13,color:T.text2,fontWeight:500})}>
          You're 4 steps away from publishing your first Play Store app.
        </span>
      </div>
      {steps.map((s,i)=>(
        <div key={i} style={{ display:"flex",gap:13,padding:"13px 14px",
          background:T.bg,border:`1px solid ${T.border}`,borderRadius:10 }}>
          <div style={{ width:32,height:32,borderRadius:8,flexShrink:0,
            background:`${s.color}18`,border:`1px solid ${s.color}44`,
            display:"flex",alignItems:"center",justifyContent:"center" }}>
            <span style={mono({fontSize:11,fontWeight:600,color:s.color})}>{s.n}</span>
          </div>
          <div style={{ flex:1,minWidth:0 }}>
            <div style={sans({fontSize:13,fontWeight:600,color:T.text,marginBottom:4})}>{s.title}</div>
            <div style={sans({fontSize:12,color:T.text3,lineHeight:1.5,marginBottom:s.cta?7:0})}>
              {s.body}
            </div>
            {s.cta && (
              s.action
                ? <button onClick={s.action}
                    style={mono({fontSize:10,padding:"3px 10px",borderRadius:6,
                      background:`${s.color}18`,color:s.color,
                      border:`1px solid ${s.color}44`,cursor:"pointer"})}>
                    {s.cta}
                  </button>
                : <a href={s.url} target="_blank"
                    style={mono({fontSize:10,color:s.color,textDecoration:"none",
                      padding:"3px 10px",borderRadius:6,display:"inline-block",
                      background:`${s.color}18`,border:`1px solid ${s.color}44`})}>
                    {s.cta}
                  </a>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════
   MAIN APP  — Epic 5: fully wired
══════════════════════════════════════════════════════════════ */
export default function App() {
  /* ── State ── */
  const [projects,    setProjects]    = useState([TASKLIST, EXPENSE_TRACKER]);
  const [activeId,    setActiveId]    = useState(EXPENSE_TRACKER.id);
  const [screenId,    setScreenId]    = useState(EXPENSE_TRACKER.screens[0].id);
  const [genStatus,   setGenStatus]   = useState("idle");
  const [errorMsg,    setErrorMsg]    = useState("");
  const [showExport,  setShowExport]  = useState(false);
  const [showSettings,setShowSettings]= useState(false);
  const [leftTab,     setLeftTab]     = useState("guide"); // guide|generate|inspect|theme
  const [prompt,      setPrompt]      = useState(
    "Create a simple Expense Tracker app with a dashboard and an \"Add Expense\" form"
  );

  /* ── License & API key ── */
  const [apiKey,     setApiKey]     = useState(() => lsGet("mf_api_key"));
  const [licenseKey, setLicenseKey] = useState(() => lsGet("mf_license_key"));
  const isPro = isLicenseValid(licenseKey);

  const previewRef  = useRef(null);
  const abortRef    = useRef(null);

  const active = projects.find(p=>p.id===activeId) || null;

  /* ── Settings save callback ── */
  const handleSettingsSave = useCallback((newApiKey, newLicenseKey) => {
    setApiKey(newApiKey);
    setLicenseKey(newLicenseKey);
  }, []);

  /* ── Theme sync: update project theme live ── */
  const updateTheme = useCallback(newTheme => {
    setProjects(prev => prev.map(p => p.id===activeId ? {...p, theme:newTheme} : p));
  }, [activeId]);

  const updateAndroid = useCallback(android => {
    setProjects(prev => prev.map(p => p.id===activeId ? {...p, android} : p));
  }, [activeId]);

  /* ══════════════════════════════════════════
     FULL GENERATION PIPELINE — Epic 5 E1.13
  ══════════════════════════════════════════ */
  const runGeneration = useCallback(async (userPrompt) => {
    if (!userPrompt.trim()) return;
    setGenStatus("idle");
    setErrorMsg("");
    await new Promise(r => setTimeout(r, 50));

    try {
      /* Step 1 — Analyze */
      setGenStatus("analyzing");
      const complexity = detectComplexity(userPrompt);
      const perms      = inferPerms(userPrompt);
      await new Promise(r => setTimeout(r, 600));

      /* Step 2 — Generate (real Claude API call) */
      setGenStatus("generating");
      const systemPrompt = buildSystemPrompt(complexity, perms);
      const userMsg = `Generate a React Native app for the following description. Respond with JSON only.\n\nApp description: ${userPrompt.slice(0,800)}\n\nComplexity: ${complexity}\nRequired permissions: ${perms.join(",")||"none"}`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{ "Content-Type":"application/json", ...(apiKey?{"x-api-key":apiKey}:{}) },
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:4096,
          system: systemPrompt,
          messages:[{ role:"user", content:userMsg }],
        }),
      });

      if (!response.ok) {
        const errText = await response.text().catch(()=>"");
        throw new Error(`API returned ${response.status}: ${errText.slice(0,200)}`);
      }

      const apiData = await response.json();
      const rawText = (apiData.content||[])
        .filter(b=>b.type==="text")
        .map(b=>b.text||"")
        .join("");

      if (!rawText.trim()) throw new Error("AI returned an empty response");

      /* Step 3 — Parse */
      setGenStatus("parsing");
      await new Promise(r => setTimeout(r, 300));
      const project = parseResponse(rawText);

      /* Step 4 — Validate */
      setGenStatus("validating");
      await new Promise(r => setTimeout(r, 300));
      const errors = validateProject(project);
      if (errors.length > 0) throw new Error(`Validation failed:\n${errors.join("\n")}`);

      /* Step 5 — Save & activate */
      setProjects(prev => {
        const without = prev.filter(p=>p.id!==project.id);
        return [project, ...without];
      });
      setActiveId(project.id);
      setScreenId(project.screens.find(s=>s.isInitialScreen)?.id || project.screens[0].id);
      setGenStatus("success");

      // Auto-scroll to preview
      setTimeout(() => previewRef.current?.scrollIntoView({behavior:"smooth"}), 400);

    } catch(err) {
      console.error("Generation error:", err);
      setErrorMsg(err.message || "Unknown error");
      setGenStatus("error");
    }
  }, []);

  /* ── Section chrome ── */
  const sectionWrap = (children, extra={}) => (
    <div style={{ background:T.bg1, border:`1px solid ${T.border}`,
      borderRadius:12, padding:"20px 22px", ...extra }}>
      {children}
    </div>
  );
  const sectionHead = (title, right=null) => (
    <div style={{ display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:16 }}>
      <div style={{ display:"flex",alignItems:"center",gap:9 }}>
        <div style={{ width:3,height:14,background:T.amber,borderRadius:2 }}/>
        <span style={lbl({fontSize:11})}>{title}</span>
      </div>
      {right}
    </div>
  );

  const examples = [
    "Recipe app with saved favourites and search",
    "Fitness tracker with daily streaks and charts",
    "Photo journal with camera and cloud upload",
    "Budget planner with categories and reports",
  ];

  return (
    <>
      <style>{FONTS + BASE}</style>

      <div style={{ minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column" }}>

        {/* ══ STICKY TOP BAR ══ */}
        <div style={{ position:"sticky",top:0,zIndex:50,background:T.bg,
          borderBottom:`1px solid ${T.border}`,
          display:"flex",alignItems:"center",padding:"0 18px",height:48,gap:10 }}>

          {/* Logo */}
          <div style={{ display:"flex",alignItems:"center",gap:9 }}>
            <div style={{ width:26,height:26,borderRadius:7,flexShrink:0,
              background:`linear-gradient(135deg,${T.amber},${T.amber2})`,
              display:"flex",alignItems:"center",justifyContent:"center",
              boxShadow:`0 0 14px ${T.amber}55` }}>
              <span style={{ fontSize:14,fontWeight:900,color:T.bg }}>M</span>
            </div>
            <span style={syne({fontWeight:800,fontSize:15,color:T.text,letterSpacing:"-0.01em"})}>
              META<span style={{color:T.amber}}>FORGE</span>
            </span>
            <span style={mono({fontSize:9,padding:"2px 7px",borderRadius:4,
              background:isPro?T.greenDim:T.amberDim,
              color:isPro?T.green:T.amber,
              border:`1px solid ${isPro?T.green:T.amber}33`})}>
              {isPro ? "PRO" : "LOCKED"}
            </span>
          </div>

          <div style={{ width:1,height:20,background:T.border,margin:"0 4px" }}/>

          {/* Active project breadcrumb */}
          {active && (
            <div style={{ display:"flex",alignItems:"center",gap:6,minWidth:0 }}>
              <span style={mono({fontSize:10,color:T.text3,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:120})}>
                {active.name}
              </span>
              <span style={{color:T.border2}}>›</span>
              <span style={mono({fontSize:10,color:T.text3})}>
                {active.screens.find(s=>s.id===screenId)?.name||""}
              </span>
            </div>
          )}

          <div style={{ flex:1 }}/>

          {/* Jump to preview */}
          <button onClick={()=>previewRef.current?.scrollIntoView({behavior:"smooth"})}
            style={mono({fontSize:10,padding:"5px 12px",borderRadius:20,
              background:T.greenDim,color:T.green,border:`1px solid ${T.green}44`,
              cursor:"pointer",letterSpacing:"0.05em",transition:"all .15s",flexShrink:0})}
            onMouseEnter={e=>e.target.style.background=`${T.green}30`}
            onMouseLeave={e=>e.target.style.background=T.greenDim}>
            ↓ Jump to Preview
          </button>

          {/* Status dot */}
          <div style={{ display:"flex",alignItems:"center",gap:5,flexShrink:0 }}>
            <div style={{ width:7,height:7,borderRadius:"50%",
              background:genStatus==="success"?T.green:genStatus==="error"?T.red:genStatus!=="idle"?T.amber:T.border2,
              animation:!["idle","success","error"].includes(genStatus)?"pdot 1s ease-in-out infinite":"none" }}/>
            <span style={mono({fontSize:10,color:T.text3,textTransform:"uppercase"})}>
              {genStatus==="idle"?"Ready":genStatus}
            </span>
          </div>

          {/* ⚙ Settings */}
          <button onClick={()=>setShowSettings(true)}
            style={{ width:34,height:34,borderRadius:8,background:T.bg2,
              border:`1px solid ${T.border2}`,cursor:"pointer",color:T.text2,
              fontSize:16,display:"flex",alignItems:"center",justifyContent:"center",
              transition:"all .15s",flexShrink:0 }}
            title="Settings & Activation"
            onMouseEnter={e=>e.currentTarget.style.borderColor=T.amber}
            onMouseLeave={e=>e.currentTarget.style.borderColor=T.border2}>
            ⚙
          </button>

          {/* Export — paywalled */}
          {active && (
            isPro
              ? <button onClick={()=>setShowExport(true)}
                  style={mono({fontSize:11,padding:"6px 14px",borderRadius:8,fontWeight:600,
                    background:T.amberDim,color:T.amber,border:`1px solid ${T.amber}44`,
                    cursor:"pointer",letterSpacing:"0.05em",transition:"all .15s",flexShrink:0})}
                  onMouseEnter={e=>e.currentTarget.style.background=`${T.amber}2a`}
                  onMouseLeave={e=>e.currentTarget.style.background=T.amberDim}>
                  ↓ EXPORT
                </button>
              : <button onClick={()=>window.open(STORE_URL,"_blank")}
                  style={syne({fontSize:11,fontWeight:700,padding:"6px 14px",borderRadius:8,
                    background:`linear-gradient(135deg,${T.amber},${T.amber2})`,
                    color:"#0c0c0f",border:"none",cursor:"pointer",
                    boxShadow:`0 2px 12px ${T.amber}55`,letterSpacing:"0.05em",flexShrink:0,
                    animation:"pdot 2s ease-in-out infinite"})}>
                  🔒 Unlock Pro — $35
                </button>
          )}
        </div>

        {/* ══ PAGE BODY — vertical stack ══ */}
        <div style={{ maxWidth:700,margin:"0 auto",width:"100%",
          padding:"22px 16px 56px",display:"flex",flexDirection:"column",gap:14 }}>

          {/* ── SECTION 1: Generation Workspace ── */}
          {sectionWrap(<>
            {sectionHead("Generation Workspace", (
              <div style={{ display:"flex",gap:1,background:T.bg,borderRadius:8,
                border:`1px solid ${T.border}`,overflow:"hidden" }}>
                {[["guide","Guide"],["generate","Generate"],["inspect","Inspect"],["theme","Theme"]].map(([id,lbl_])=>(
                  <button key={id} onClick={()=>setLeftTab(id)}
                    style={mono({fontSize:10,padding:"5px 12px",border:"none",cursor:"pointer",
                      background:leftTab===id?T.amber:T.bg,
                      color:leftTab===id?"#0c0c0f":T.text3,
                      transition:"all .15s",textTransform:"uppercase",letterSpacing:"0.07em"})}>
                    {lbl_}
                  </button>
                ))}
              </div>
            ))}

            {/* GUIDE TAB */}
            {leftTab==="guide" && (
              <QuickStartGuide onOpenSettings={()=>setShowSettings(true)}/>
            )}

            {/* GENERATE TAB */}
            {leftTab==="generate" && (
              <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
                <div style={{ position:"relative" }}>
                  <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={4}
                    placeholder="Describe your app in plain English…"
                    style={sans({width:"100%",fontSize:14,lineHeight:1.65,
                      background:T.bg,color:T.text,border:`1px solid ${T.border2}`,
                      borderRadius:9,padding:"12px 14px 28px",resize:"vertical"})}
                    onFocus={e=>e.target.style.borderColor=`${T.amber}88`}
                    onBlur={e=>e.target.style.borderColor=T.border2}/>
                  <span style={mono({position:"absolute",bottom:9,right:11,fontSize:9,color:T.text4})}>
                    {prompt.length}/800
                  </span>
                </div>

                {/* Generate / Unlock button — paywalled */}
                {isPro
                  ? <button onClick={()=>runGeneration(prompt)}
                      disabled={["analyzing","generating","parsing","validating"].includes(genStatus)||!prompt.trim()}
                      style={syne({width:"100%",fontWeight:700,fontSize:14,letterSpacing:"0.07em",
                        padding:"14px",borderRadius:10,border:"none",
                        cursor:["analyzing","generating","parsing","validating"].includes(genStatus)||!prompt.trim()?"not-allowed":"pointer",
                        background:["analyzing","generating","parsing","validating"].includes(genStatus)?T.bg3
                          :prompt.trim()?`linear-gradient(135deg,${T.amber},${T.amber2})`:T.bg3,
                        color:["analyzing","generating","parsing","validating"].includes(genStatus)?T.text3:"#0c0c0f",
                        boxShadow:!["analyzing","generating","parsing","validating"].includes(genStatus)&&prompt.trim()?`0 4px 20px ${T.amber}44`:"none",
                        transition:"all .2s"})}>
                      {["analyzing","generating","parsing","validating"].includes(genStatus)
                        ?<span style={{display:"flex",alignItems:"center",justifyContent:"center",gap:10}}>
                            <span style={{display:"inline-block",animation:"spin 1s linear infinite"}}>⟳</span>
                            GENERATING…
                          </span>
                        :"GENERATE APP  ⌘↵"}
                    </button>
                  : <button onClick={()=>window.open(STORE_URL,"_blank")}
                      style={syne({width:"100%",fontWeight:700,fontSize:14,letterSpacing:"0.05em",
                        padding:"14px",borderRadius:10,border:"none",cursor:"pointer",
                        background:`linear-gradient(135deg,${T.amber},${T.amber2})`,
                        color:"#0c0c0f",boxShadow:`0 4px 24px ${T.amber}55`,transition:"all .2s"})}>
                      🔒 Unlock Pro for $35 — Generate Unlimited Apps
                    </button>
                }

                <Pipeline
                  status={genStatus} errorMsg={errorMsg}
                  onRetry={()=>runGeneration(prompt)} prompt={prompt}/>

                <div style={{ marginTop:8 }}>
                  <div style={{...lbl(),marginBottom:9}}>Example prompts</div>
                  <div style={{ display:"flex",flexDirection:"column",gap:6 }}>
                    {examples.map((ex,i)=>(
                      <button key={i} onClick={()=>setPrompt(ex)}
                        style={sans({textAlign:"left",fontSize:13,color:T.text3,
                          background:T.bg,border:`1px solid ${T.border}`,
                          borderRadius:8,padding:"9px 13px",cursor:"pointer",
                          lineHeight:1.4,transition:"all .12s"})}
                        onMouseEnter={e=>{e.target.style.color=T.text2;e.target.style.borderColor=T.border2;}}
                        onMouseLeave={e=>{e.target.style.color=T.text3;e.target.style.borderColor=T.border;}}>
                        {ex}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* INSPECT TAB */}
            {leftTab==="inspect" && (
              <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
                {/* Project list */}
                <div>
                  <div style={{...lbl(),marginBottom:9}}>Projects ({projects.length})</div>
                  <div style={{ display:"flex",flexDirection:"column",gap:5 }}>
                    {projects.map(p=>(
                      <div key={p.id}
                        onClick={()=>{setActiveId(p.id);setScreenId(p.screens.find(s=>s.isInitialScreen)?.id||p.screens[0].id);}}
                        style={{ display:"flex",alignItems:"center",justifyContent:"space-between",
                          padding:"10px 13px",borderRadius:8,cursor:"pointer",
                          background:p.id===activeId?T.bg3:T.bg,
                          border:`1px solid ${p.id===activeId?T.border2:T.border}`,
                          transition:"all .12s" }}
                        onMouseEnter={e=>{if(p.id!==activeId)e.currentTarget.style.background=T.bg2;}}
                        onMouseLeave={e=>{if(p.id!==activeId)e.currentTarget.style.background=T.bg;}}>
                        <div>
                          <span style={sans({fontSize:14,fontWeight:500,color:p.id===activeId?T.text:T.text2})}>
                            {p.name}
                          </span>
                          <span style={mono({fontSize:10,color:T.text3,marginLeft:10})}>
                            {(p.complexity||"").toUpperCase()} · {p.screens?.length}s
                          </span>
                        </div>
                        {p.id===activeId&&<span style={pill(T.amber)}>ACTIVE</span>}
                      </div>
                    ))}
                  </div>
                </div>
                {/* Screen tree — E5.2 */}
                {active && (
                  <div>
                    <div style={{...lbl(),marginBottom:9}}>Screen Tree — click to switch preview</div>
                    <div style={{ display:"flex",flexDirection:"column",gap:4 }}>
                      {active.screens.map((s,i)=>{
                        const isCur=s.id===screenId;
                        return(
                          <div key={s.id}
                            onClick={()=>{ setScreenId(s.id); previewRef.current?.scrollIntoView({behavior:"smooth"}); }}
                            style={{ display:"flex",alignItems:"center",gap:10,padding:"9px 12px",
                              borderRadius:8,cursor:"pointer",
                              background:isCur?`${active.theme?.primaryColor||T.amber}18`:T.bg,
                              border:`1px solid ${isCur?`${active.theme?.primaryColor||T.amber}55`:T.border}`,
                              transition:"all .15s" }}>
                            <div style={{ width:20,height:20,borderRadius:5,flexShrink:0,
                              background:isCur?active.theme?.primaryColor||T.amber:T.bg3,
                              display:"flex",alignItems:"center",justifyContent:"center" }}>
                              <span style={{ fontSize:10,color:isCur?"#0c0c0f":T.text3 }}>{i+1}</span>
                            </div>
                            <div style={{ flex:1,minWidth:0 }}>
                              <div style={sans({fontSize:13,fontWeight:500,
                                color:isCur?T.text:T.text2})}>{s.name}</div>
                              <div style={mono({fontSize:10,color:T.text3})}>{s.route} · {s.components.length} components</div>
                            </div>
                            {s.isInitialScreen&&<span style={pill(T.green,{fontSize:9})}>initial</span>}
                            {isCur&&<span style={mono({fontSize:9,color:active.theme?.primaryColor||T.amber})}>●</span>}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                {active && (
                  <div>
                    <div style={{...lbl(),marginBottom:9}}>Android Config</div>
                    <AndroidInspector project={active} onUpdate={updateAndroid}/>
                  </div>
                )}
              </div>
            )}

            {/* THEME TAB — E5.4 live theme sync */}
            {leftTab==="theme" && (
              <div style={{ display:"flex",flexDirection:"column",gap:12 }}>
                {active
                  ? <>
                      <div style={{ display:"flex",alignItems:"center",gap:8,padding:"9px 12px",
                        background:T.bg,borderRadius:8,border:`1px solid ${T.border}` }}>
                        <div style={{ width:8,height:8,borderRadius:"50%",background:T.green,
                          boxShadow:`0 0 6px ${T.green}88`,animation:"pdot 2s ease-in-out infinite" }}/>
                        <span style={mono({fontSize:11,color:T.text3})}>
                          Theme changes sync instantly to Live Preview below
                        </span>
                      </div>
                      <ThemeEditor theme={active.theme||{}} onChange={updateTheme}/>
                    </>
                  : <div style={mono({fontSize:12,color:T.text3})}>No project selected</div>}
              </div>
            )}
          </>)}

          {/* ── SECTION 2: Live Preview ── */}
          <div ref={previewRef} style={{ background:T.bg1,border:`1px solid ${T.border}`,
            borderRadius:12,padding:"20px 22px" }}>

            {sectionHead(
              "Live Preview — React Native Web",
              <div style={{ display:"flex",alignItems:"center",gap:8 }}>
                <div style={{ width:7,height:7,borderRadius:"50%",background:T.green,
                  boxShadow:`0 0 8px ${T.green}88`,animation:"pdot 3s ease-in-out infinite" }}/>
                <span style={mono({fontSize:10,color:T.text3})}>interactive · 0.75×</span>
              </div>
            )}

            {/* Generation in-progress overlay */}
            {["analyzing","generating","parsing","validating"].includes(genStatus) && (
              <div style={{ textAlign:"center",padding:"32px 0",animation:"fi .3s ease" }}>
                <div style={{ display:"inline-flex",alignItems:"center",gap:12,padding:"14px 22px",
                  background:T.amberDim,border:`1px solid ${T.amber}44`,borderRadius:12 }}>
                  <span style={{ display:"inline-block",animation:"spin 1s linear infinite",
                    fontSize:20,color:T.amber }}>⟳</span>
                  <span style={sans({fontSize:14,color:T.amber,fontWeight:500})}>
                    {genStatus==="analyzing"?"Analyzing your prompt…"
                      :genStatus==="generating"?"Claude is building your app…"
                      :genStatus==="parsing"?"Parsing the response…"
                      :"Validating schema…"}
                  </span>
                </div>
              </div>
            )}

            {/* Preview — only show when not generating */}
            {!["analyzing","generating","parsing","validating"].includes(genStatus) && (
              active
                ? <PhoneFrame project={active} activeScreenId={screenId} onScreenChange={id=>{
                    setScreenId(id);
                  }}/>
                : <div style={{ textAlign:"center",padding:"40px 0" }}>
                    <div style={{ fontSize:28,marginBottom:10,color:T.text4 }}>⬡</div>
                    <span style={mono({fontSize:12,color:T.text3})}>Generate an app to preview it here</span>
                  </div>
            )}

            {/* Expense Tracker demo callout */}
            {active?.id==="expense-tracker-demo" && (
              <div style={{ marginTop:16,padding:"11px 14px",
                background:T.greenDim,border:`1px solid ${T.green}44`,borderRadius:9,
                display:"flex",alignItems:"flex-start",gap:10,animation:"fi .4s ease" }}>
                <span style={{color:T.green,fontSize:14,marginTop:1}}>✓</span>
                <div>
                  <div style={sans({fontWeight:600,fontSize:13,color:T.green,marginBottom:3})}>
                    Full-cycle test complete — Expense Tracker loaded
                  </div>
                  <div style={mono({fontSize:11,color:`${T.green}cc`,lineHeight:1.6})}>
                    3 screens (Dashboard · Add · History) · tab navigation · 2 inputs ·
                    package: com.example.expensetracker · all Play Store checks ✓
                  </div>
                </div>
              </div>
            )}
          </div>

        </div>{/* /body */}
      </div>{/* /root */}

      {showExport&&active&&<ExportModal project={active} onClose={()=>setShowExport(false)}/>}
      {showSettings&&<SettingsModal onClose={()=>setShowSettings(false)} onSave={handleSettingsSave}/>}
    </>
  );
}
